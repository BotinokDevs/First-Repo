module.exports = {
	name: 'test',
	description: 'Bakayarou!',
	execute(message) {
		message.channel.send('ばかやろう!');
	},
};